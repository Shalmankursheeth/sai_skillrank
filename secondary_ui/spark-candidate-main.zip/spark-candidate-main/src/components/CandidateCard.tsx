import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { MapPin, Mail, Phone, Calendar } from "lucide-react";

interface Candidate {
  id: number;
  name: string;
  email: string;
  phone?: string;
  location?: string;
  title?: string;
  skills: string[];
  experience_years?: number;
  created_at: string;
}

interface CandidateCardProps {
  candidate: Candidate;
  onViewProfile?: (candidate: Candidate) => void;
}

const CandidateCard = ({ candidate, onViewProfile }: CandidateCardProps) => {
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  return (
    <Card className="hover:shadow-hover transition-shadow duration-200">
      <CardHeader>
        <div className="flex items-center space-x-3">
          <Avatar className="w-12 h-12">
            <AvatarFallback className="bg-professional text-professional-foreground">
              {getInitials(candidate.name)}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <h3 className="text-lg font-semibold text-foreground truncate">
              {candidate.name}
            </h3>
            {candidate.title && (
              <p className="text-sm text-muted-foreground truncate">
                {candidate.title}
              </p>
            )}
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <Mail className="w-4 h-4 flex-shrink-0" />
            <span className="truncate">{candidate.email}</span>
          </div>
          
          {candidate.phone && (
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <Phone className="w-4 h-4 flex-shrink-0" />
              <span>{candidate.phone}</span>
            </div>
          )}
          
          {candidate.location && (
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <MapPin className="w-4 h-4 flex-shrink-0" />
              <span>{candidate.location}</span>
            </div>
          )}
          
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <Calendar className="w-4 h-4 flex-shrink-0" />
            <span>
              {candidate.experience_years 
                ? `${candidate.experience_years} years experience` 
                : `Joined ${formatDate(candidate.created_at)}`
              }
            </span>
          </div>
        </div>

        <div className="flex flex-wrap gap-1">
          {candidate.skills.slice(0, 4).map((skill, index) => (
            <Badge key={index} variant="outline" className="text-xs">
              {skill}
            </Badge>
          ))}
          {candidate.skills.length > 4 && (
            <Badge variant="outline" className="text-xs">
              +{candidate.skills.length - 4} more
            </Badge>
          )}
        </div>

        <div className="flex space-x-2 pt-2">
          <Button 
            variant="default" 
            size="sm" 
            onClick={() => onViewProfile?.(candidate)}
            className="flex-1"
          >
            View Profile
          </Button>
          <Button variant="outline" size="sm">
            Contact
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default CandidateCard;