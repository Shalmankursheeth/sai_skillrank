import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Clock, DollarSign } from "lucide-react";

interface Job {
  id: number;
  title: string;
  company: string;
  location: string;
  salary_min?: number;
  salary_max?: number;
  employment_type: string;
  description: string;
  required_skills: string[];
  created_at: string;
}

interface JobCardProps {
  job: Job;
  onViewDetails?: (job: Job) => void;
}

const JobCard = ({ job, onViewDetails }: JobCardProps) => {
  const formatSalary = () => {
    if (job.salary_min && job.salary_max) {
      return `$${job.salary_min.toLocaleString()} - $${job.salary_max.toLocaleString()}`;
    }
    return "Salary negotiable";
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  return (
    <Card className="hover:shadow-hover transition-shadow duration-200">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div className="space-y-2">
            <CardTitle className="text-lg font-semibold text-foreground">
              {job.title}
            </CardTitle>
            <p className="text-sm text-muted-foreground font-medium">{job.company}</p>
          </div>
          <Badge variant="secondary" className="text-xs">
            {job.employment_type}
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="flex items-center space-x-4 text-sm text-muted-foreground">
          <div className="flex items-center space-x-1">
            <MapPin className="w-4 h-4" />
            <span>{job.location}</span>
          </div>
          <div className="flex items-center space-x-1">
            <DollarSign className="w-4 h-4" />
            <span>{formatSalary()}</span>
          </div>
          <div className="flex items-center space-x-1">
            <Clock className="w-4 h-4" />
            <span>{formatDate(job.created_at)}</span>
          </div>
        </div>

        <p className="text-sm text-muted-foreground line-clamp-2">
          {job.description}
        </p>

        <div className="flex flex-wrap gap-1">
          {job.required_skills.slice(0, 3).map((skill, index) => (
            <Badge key={index} variant="outline" className="text-xs">
              {skill}
            </Badge>
          ))}
          {job.required_skills.length > 3 && (
            <Badge variant="outline" className="text-xs">
              +{job.required_skills.length - 3} more
            </Badge>
          )}
        </div>

        <div className="flex space-x-2 pt-2">
          <Button 
            variant="default" 
            size="sm" 
            onClick={() => onViewDetails?.(job)}
            className="flex-1"
          >
            View Details
          </Button>
          <Button variant="outline" size="sm">
            Save Job
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default JobCard;