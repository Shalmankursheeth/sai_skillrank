const API_BASE_URL = "http://127.0.0.1:8000";

// API client configuration
const apiClient = {
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
};

// Generic API request function
export const apiRequest = async (endpoint: string, options: RequestInit = {}) => {
  const url = `${apiClient.baseURL}${endpoint}`;
  const config = {
    ...options,
    headers: {
      ...apiClient.headers,
      ...options.headers,
    },
  };

  try {
    const response = await fetch(url, config);
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('API request failed:', error);
    throw error;
  }
};

// Job-related API functions
export const jobsAPI = {
  getAll: () => apiRequest('/jobs'),
  getById: (id: number) => apiRequest(`/jobs/${id}`),
  create: (job: any) => apiRequest('/jobs', {
    method: 'POST',
    body: JSON.stringify(job),
  }),
  update: (id: number, job: any) => apiRequest(`/jobs/${id}`, {
    method: 'PUT',
    body: JSON.stringify(job),
  }),
  delete: (id: number) => apiRequest(`/jobs/${id}`, {
    method: 'DELETE',
  }),
};

// Candidate-related API functions
export const candidatesAPI = {
  getAll: () => apiRequest('/candidates'),
  getById: (id: number) => apiRequest(`/candidates/${id}`),
  create: (candidate: any, runExtract: boolean = false) => {
    const url = runExtract ? '/candidates?run_extract=true' : '/candidates';
    return apiRequest(url, {
      method: 'POST',
      body: JSON.stringify(candidate),
    });
  },
  update: (id: number, candidate: any) => apiRequest(`/candidates/${id}`, {
    method: 'PUT',
    body: JSON.stringify(candidate),
  }),
  delete: (id: number) => apiRequest(`/candidates/${id}`, {
    method: 'DELETE',
  }),
  extractSkills: (id: number) => apiRequest(`/candidates/${id}/extract`, {
    method: 'PUT',
  }),
};

// Resume-related API functions
export const resumesAPI = {
  getAll: () => apiRequest('/resumes'),
  getById: (id: number) => apiRequest(`/resumes/${id}`),
  upload: (formData: FormData) => apiRequest('/resumes/upload', {
    method: 'POST',
    body: formData,
    headers: {}, // Let browser set Content-Type for FormData
  }),
  delete: (id: number) => apiRequest(`/resumes/${id}`, {
    method: 'DELETE',
  }),
};

// Match-related API functions
export const matchesAPI = {
  getAll: () => apiRequest('/matches'),
  create: (jobId: number, candidateId: number) => apiRequest('/matches', {
    method: 'POST',
    body: JSON.stringify({ job_id: jobId, candidate_id: candidateId }),
  }),
  updateStatus: (id: number, status: string) => apiRequest(`/matches/${id}/status`, {
    method: 'PUT',
    body: JSON.stringify({ status }),
  }),
};