import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, Search, FileText, Download, Eye, Trash2 } from "lucide-react";

interface Resume {
  id: number;
  candidate_name: string;
  file_name: string;
  file_size: string;
  upload_date: string;
  status: "pending" | "reviewed" | "approved" | "rejected";
  tags: string[];
}

const Resumes = () => {
  const [resumes, setResumes] = useState<Resume[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  // Mock data for demonstration
  const mockResumes: Resume[] = [
    {
      id: 1,
      candidate_name: "Sarah Johnson",
      file_name: "sarah_johnson_resume.pdf",
      file_size: "1.2 MB",
      upload_date: "2024-01-15T10:00:00Z",
      status: "approved",
      tags: ["Frontend", "React", "TypeScript"]
    },
    {
      id: 2,
      candidate_name: "Michael Chen",
      file_name: "michael_chen_cv.pdf",
      file_size: "890 KB",
      upload_date: "2024-01-14T15:30:00Z",
      status: "reviewed",
      tags: ["Backend", "Python", "FastAPI"]
    },
    {
      id: 3,
      candidate_name: "Emily Rodriguez",
      file_name: "emily_rodriguez_resume.docx",
      file_size: "1.5 MB",
      upload_date: "2024-01-13T09:15:00Z",
      status: "pending",
      tags: ["Full Stack", "JavaScript", "Node.js"]
    },
    {
      id: 4,
      candidate_name: "David Kim",
      file_name: "david_kim_resume.pdf",
      file_size: "2.1 MB",
      upload_date: "2024-01-12T11:45:00Z",
      status: "rejected",
      tags: ["DevOps", "AWS", "Kubernetes"]
    }
  ];

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setResumes(mockResumes);
      setLoading(false);
    }, 1000);
  }, []);

  const filteredResumes = resumes.filter(resume => {
    return resume.candidate_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
           resume.file_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
           resume.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
  });

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  const getStatusColor = (status: Resume['status']) => {
    switch (status) {
      case 'approved':
        return 'bg-success text-success-foreground';
      case 'rejected':
        return 'bg-destructive text-destructive-foreground';
      case 'reviewed':
        return 'bg-info text-info-foreground';
      default:
        return 'bg-warning text-warning-foreground';
    }
  };

  const handleAction = (action: string, resume: Resume) => {
    console.log(`${action} resume:`, resume);
    // TODO: Implement actual actions (view, download, delete)
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-muted rounded w-1/4"></div>
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-24 bg-muted rounded-lg"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-6">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Resume Management</h1>
              <p className="text-muted-foreground mt-1">
                {filteredResumes.length} {filteredResumes.length === 1 ? 'resume' : 'resumes'} in database
              </p>
            </div>
            <Button className="mt-4 sm:mt-0">
              <Plus className="w-4 h-4 mr-2" />
              Upload Resume
            </Button>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search resumes by name, filename, or skills..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Resume List */}
          <div className="space-y-4">
            {filteredResumes.map((resume) => (
              <Card key={resume.id} className="hover:shadow-hover transition-shadow duration-200">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-professional rounded-lg flex items-center justify-center">
                        <FileText className="w-5 h-5 text-professional-foreground" />
                      </div>
                      <div>
                        <CardTitle className="text-lg font-semibold text-foreground">
                          {resume.candidate_name}
                        </CardTitle>
                        <p className="text-sm text-muted-foreground">{resume.file_name}</p>
                      </div>
                    </div>
                    <Badge className={getStatusColor(resume.status)}>
                      {resume.status}
                    </Badge>
                  </div>
                </CardHeader>
                
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-6 text-sm text-muted-foreground">
                      <span>Size: {resume.file_size}</span>
                      <span>Uploaded: {formatDate(resume.upload_date)}</span>
                      <div className="flex space-x-1">
                        {resume.tags.map((tag, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleAction('view', resume)}
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleAction('download', resume)}
                      >
                        <Download className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleAction('delete', resume)}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredResumes.length === 0 && (
            <div className="text-center py-12">
              <p className="text-muted-foreground text-lg">No resumes found matching your search.</p>
              <Button className="mt-4" onClick={() => setSearchTerm("")}>
                Clear Search
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Resumes;