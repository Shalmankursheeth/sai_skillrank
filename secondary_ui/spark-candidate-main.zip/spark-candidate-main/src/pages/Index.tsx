import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Target, Briefcase, Users, FileText, TrendingUp } from "lucide-react";

const Index = () => {
  const stats = [
    { label: "Active Jobs", value: "127", icon: Briefcase },
    { label: "Candidates", value: "2,384", icon: Users },
    { label: "Resumes", value: "1,847", icon: FileText },
    { label: "Successful Matches", value: "342", icon: TrendingUp },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Hero Section */}
        <div className="text-center space-y-6 mb-16">
          <div className="inline-flex items-center space-x-2 bg-gradient-hero text-primary-foreground px-6 py-3 rounded-full">
            <Target className="w-5 h-5" />
            <span className="font-semibold">JobMatch Platform</span>
          </div>
          
          <h1 className="text-5xl font-bold text-foreground">
            Smart Job-Candidate Matching
          </h1>
          
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Connect the right talent with the right opportunities using AI-powered matching algorithms.
            Streamline your recruitment process and find perfect matches faster than ever.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" asChild>
              <Link to="/jobs">Browse Jobs</Link>
            </Button>
            <Button variant="outline" size="lg" asChild>
              <Link to="/candidates">View Candidates</Link>
            </Button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {stats.map((stat, index) => (
            <Card key={index} className="text-center hover:shadow-hover transition-shadow duration-200">
              <CardHeader className="pb-2">
                <div className="w-12 h-12 bg-professional rounded-lg flex items-center justify-center mx-auto">
                  <stat.icon className="w-6 h-6 text-professional-foreground" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-foreground">{stat.value}</div>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="hover:shadow-hover transition-shadow duration-200">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Briefcase className="w-5 h-5 text-primary" />
                <span>Jobs</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Manage job postings and view applications
              </p>
              <Button variant="outline" className="w-full" asChild>
                <Link to="/jobs">View All Jobs</Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-hover transition-shadow duration-200">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Users className="w-5 h-5 text-primary" />
                <span>Candidates</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Browse candidate profiles and skills
              </p>
              <Button variant="outline" className="w-full" asChild>
                <Link to="/candidates">View Candidates</Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-hover transition-shadow duration-200">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <FileText className="w-5 h-5 text-primary" />
                <span>Resumes</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Upload and manage resume documents
              </p>
              <Button variant="outline" className="w-full" asChild>
                <Link to="/resumes">Manage Resumes</Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-hover transition-shadow duration-200">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Target className="w-5 h-5 text-primary" />
                <span>Matches</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                AI-powered job-candidate matching
              </p>
              <Button variant="outline" className="w-full" asChild>
                <Link to="/matches">View Matches</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Index;
