import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Search, Target, User, Briefcase, Percent, ArrowRight } from "lucide-react";

interface Match {
  id: number;
  candidate_name: string;
  candidate_email: string;
  job_title: string;
  company: string;
  match_score: number;
  matching_skills: string[];
  missing_skills: string[];
  created_at: string;
  status: "new" | "contacted" | "interviewing" | "hired" | "rejected";
}

const Matches = () => {
  const [matches, setMatches] = useState<Match[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  // Mock data for demonstration
  const mockMatches: Match[] = [
    {
      id: 1,
      candidate_name: "Sarah Johnson",
      candidate_email: "sarah.johnson@email.com",
      job_title: "Senior Frontend Developer",
      company: "TechCorp Inc.",
      match_score: 92,
      matching_skills: ["React", "TypeScript", "JavaScript", "CSS"],
      missing_skills: ["Next.js"],
      created_at: "2024-01-15T10:00:00Z",
      status: "new"
    },
    {
      id: 2,
      candidate_name: "Michael Chen",
      candidate_email: "michael.chen@email.com",
      job_title: "Backend Engineer",
      company: "DataFlow Solutions",
      match_score: 88,
      matching_skills: ["Python", "FastAPI", "PostgreSQL", "Docker"],
      missing_skills: ["Kubernetes"],
      created_at: "2024-01-14T15:30:00Z",
      status: "contacted"
    },
    {
      id: 3,
      candidate_name: "Emily Rodriguez",
      candidate_email: "emily.rodriguez@email.com",
      job_title: "Full Stack Developer",
      company: "StartupXYZ",
      match_score: 85,
      matching_skills: ["React", "Node.js", "JavaScript", "MongoDB"],
      missing_skills: ["GraphQL", "AWS"],
      created_at: "2024-01-13T09:15:00Z",
      status: "interviewing"
    },
    {
      id: 4,
      candidate_name: "David Kim",
      candidate_email: "david.kim@email.com",
      job_title: "DevOps Engineer",
      company: "CloudTech Solutions",
      match_score: 79,
      matching_skills: ["Docker", "AWS", "Kubernetes"],
      missing_skills: ["Terraform", "Jenkins"],
      created_at: "2024-01-12T11:45:00Z",
      status: "new"
    }
  ];

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setMatches(mockMatches);
      setLoading(false);
    }, 1000);
  }, []);

  const filteredMatches = matches.filter(match => {
    return match.candidate_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
           match.job_title.toLowerCase().includes(searchTerm.toLowerCase()) ||
           match.company.toLowerCase().includes(searchTerm.toLowerCase());
  });

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return "bg-success text-success-foreground";
    if (score >= 80) return "bg-info text-info-foreground";
    if (score >= 70) return "bg-warning text-warning-foreground";
    return "bg-muted text-muted-foreground";
  };

  const getStatusColor = (status: Match['status']) => {
    switch (status) {
      case 'hired':
        return 'bg-success text-success-foreground';
      case 'rejected':
        return 'bg-destructive text-destructive-foreground';
      case 'interviewing':
        return 'bg-info text-info-foreground';
      case 'contacted':
        return 'bg-warning text-warning-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  const handleMatchAction = (action: string, match: Match) => {
    console.log(`${action} match:`, match);
    // TODO: Implement actual actions (contact candidate, update status, etc.)
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-muted rounded w-1/4"></div>
            <div className="space-y-4">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-32 bg-muted rounded-lg"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-6">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Job Matches</h1>
              <p className="text-muted-foreground mt-1">
                {filteredMatches.length} {filteredMatches.length === 1 ? 'match' : 'matches'} found
              </p>
            </div>
            <Button className="mt-4 sm:mt-0">
              <Target className="w-4 h-4 mr-2" />
              Run New Match
            </Button>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search matches by candidate, job title, or company..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Matches List */}
          <div className="space-y-4">
            {filteredMatches.map((match) => (
              <Card key={match.id} className="hover:shadow-hover transition-shadow duration-200">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <Avatar className="w-12 h-12">
                        <AvatarFallback className="bg-professional text-professional-foreground">
                          {getInitials(match.candidate_name)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <CardTitle className="text-lg font-semibold text-foreground">
                          {match.candidate_name}
                        </CardTitle>
                        <p className="text-sm text-muted-foreground">{match.candidate_email}</p>
                      </div>
                      <ArrowRight className="w-5 h-5 text-muted-foreground mx-2" />
                      <div>
                        <p className="font-semibold text-foreground">{match.job_title}</p>
                        <p className="text-sm text-muted-foreground">{match.company}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge className={getScoreColor(match.match_score)}>
                        <Percent className="w-3 h-3 mr-1" />
                        {match.match_score}
                      </Badge>
                      <Badge className={getStatusColor(match.status)}>
                        {match.status}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="text-sm font-medium text-foreground mb-2">Matching Skills</h4>
                        <div className="flex flex-wrap gap-1">
                          {match.matching_skills.map((skill, index) => (
                            <Badge key={index} variant="default" className="text-xs">
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-foreground mb-2">Missing Skills</h4>
                        <div className="flex flex-wrap gap-1">
                          {match.missing_skills.map((skill, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between pt-2 border-t">
                      <span className="text-sm text-muted-foreground">
                        Matched on {formatDate(match.created_at)}
                      </span>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleMatchAction('contact', match)}
                        >
                          <User className="w-4 h-4 mr-1" />
                          Contact
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleMatchAction('view_job', match)}
                        >
                          <Briefcase className="w-4 h-4 mr-1" />
                          View Job
                        </Button>
                        <Button
                          variant="default"
                          size="sm"
                          onClick={() => handleMatchAction('schedule', match)}
                        >
                          Schedule Interview
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredMatches.length === 0 && (
            <div className="text-center py-12">
              <p className="text-muted-foreground text-lg">No matches found.</p>
              <Button className="mt-4" onClick={() => setSearchTerm("")}>
                Clear Search
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Matches;