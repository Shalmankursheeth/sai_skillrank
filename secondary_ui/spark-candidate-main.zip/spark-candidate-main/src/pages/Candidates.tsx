import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Plus, Search, Mail, Sparkles, User, Loader2 } from "lucide-react";
import { candidatesAPI } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

interface Candidate {
  id: number;
  name: string;
  email: string;
  resume_text?: string;
  extracted_skills?: string[];
  created_at: string;
}

const Candidates = () => {
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [showCandidateForm, setShowCandidateForm] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [extractingSkills, setExtractingSkills] = useState<number | null>(null);
  const { toast } = useToast();
  
  const [newCandidate, setNewCandidate] = useState({
    name: "",
    email: "",
    resume_text: "",
  });
  const [runExtract, setRunExtract] = useState(false);

  const fetchCandidates = async () => {
    try {
      setLoading(true);
      const response = await candidatesAPI.getAll();
      setCandidates(response);
    } catch (error) {
      console.error("Failed to fetch candidates:", error);
      toast({
        title: "Error",
        description: "Failed to fetch candidates. Using sample data instead.",
        variant: "destructive",
      });
      // Fallback to sample data if API fails
      setCandidates([
        {
          id: 1,
          name: "Sarah Johnson",
          email: "sarah.johnson@email.com",
          resume_text: "Experienced frontend developer with 5+ years in React and TypeScript...",
          extracted_skills: ["React", "TypeScript", "JavaScript", "CSS", "Node.js"],
          created_at: "2024-01-10T10:00:00Z"
        },
        {
          id: 2,
          name: "Michael Chen",
          email: "michael.chen@email.com",
          resume_text: "Backend engineer specializing in Python and cloud technologies...",
          extracted_skills: ["Python", "FastAPI", "PostgreSQL", "Docker", "AWS"],
          created_at: "2024-01-09T15:30:00Z"
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCandidates();
  }, []);

  const handleSubmitCandidate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCandidate.name || !newCandidate.email || !newCandidate.resume_text) {
      toast({
        title: "Error",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    try {
      setSubmitting(true);
      await candidatesAPI.create(newCandidate, runExtract);
      toast({
        title: "Success",
        description: `Candidate added successfully!${runExtract ? " Skills will be extracted automatically." : ""}`,
      });
      setNewCandidate({ name: "", email: "", resume_text: "" });
      setRunExtract(false);
      setShowCandidateForm(false);
      fetchCandidates(); // Refresh the candidate list
    } catch (error) {
      console.error("Failed to create candidate:", error);
      toast({
        title: "Error",
        description: "Failed to add candidate. Please try again.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleExtractSkills = async (candidateId: number) => {
    try {
      setExtractingSkills(candidateId);
      await candidatesAPI.extractSkills(candidateId);
      toast({
        title: "Success",
        description: "Skill extraction completed!",
      });
      fetchCandidates(); // Refresh to show updated skills
    } catch (error) {
      console.error("Failed to extract skills:", error);
      toast({
        title: "Error",
        description: "Failed to extract skills. Please try again.",
        variant: "destructive",
      });
    } finally {
      setExtractingSkills(null);
    }
  };

  const filteredCandidates = candidates.filter(candidate => {
    const matchesSearch = candidate.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         candidate.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         candidate.extracted_skills?.some(skill => 
                           skill.toLowerCase().includes(searchTerm.toLowerCase())
                         );
    
    return matchesSearch;
  });

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-muted rounded w-1/4"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="h-64 bg-muted rounded-lg"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-6">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Candidates</h1>
              <p className="text-muted-foreground mt-1">
                {filteredCandidates.length} {filteredCandidates.length === 1 ? 'candidate' : 'candidates'} available
              </p>
            </div>
            <Dialog open={showCandidateForm} onOpenChange={setShowCandidateForm}>
              <DialogTrigger asChild>
                <Button className="mt-4 sm:mt-0">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Candidate
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                  <DialogTitle>Add New Candidate</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmitCandidate} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name *</Label>
                    <Input
                      id="name"
                      placeholder="e.g. John Doe"
                      value={newCandidate.name}
                      onChange={(e) => setNewCandidate({ ...newCandidate, name: e.target.value })}
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address *</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="e.g. john.doe@email.com"
                      value={newCandidate.email}
                      onChange={(e) => setNewCandidate({ ...newCandidate, email: e.target.value })}
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="resume_text">Resume/CV Text *</Label>
                    <Textarea
                      id="resume_text"
                      placeholder="Paste the candidate's resume or CV text here..."
                      value={newCandidate.resume_text}
                      onChange={(e) => setNewCandidate({ ...newCandidate, resume_text: e.target.value })}
                      rows={6}
                      required
                    />
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="run_extract"
                      checked={runExtract}
                      onCheckedChange={setRunExtract}
                    />
                    <Label htmlFor="run_extract" className="text-sm">
                      Auto-extract skills from resume text
                    </Label>
                  </div>
                  
                  <div className="flex justify-end space-x-2 pt-4">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setShowCandidateForm(false)}
                    >
                      Cancel
                    </Button>
                    <Button type="submit" disabled={submitting}>
                      {submitting ? "Adding..." : "Add Candidate"}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search candidates by name, email, or skills..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Candidates List */}
          <div className="space-y-4">
            {filteredCandidates.map((candidate) => (
              <Card key={candidate.id} className="hover:shadow-hover transition-shadow duration-200">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Avatar className="w-12 h-12">
                        <AvatarFallback className="bg-professional text-professional-foreground">
                          {getInitials(candidate.name)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <CardTitle className="text-lg font-semibold text-foreground">
                          {candidate.name}
                        </CardTitle>
                        <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                          <Mail className="w-4 h-4 flex-shrink-0" />
                          <span className="truncate">{candidate.email}</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {formatDate(candidate.created_at)}
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  {candidate.extracted_skills && candidate.extracted_skills.length > 0 ? (
                    <div>
                      <h4 className="text-sm font-medium text-foreground mb-2">Extracted Skills</h4>
                      <div className="flex flex-wrap gap-1">
                        {candidate.extracted_skills.map((skill, index) => (
                          <Badge key={index} variant="default" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="text-sm text-muted-foreground">
                      No skills extracted yet
                    </div>
                  )}

                  <div className="flex justify-between items-center pt-2 border-t">
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => console.log("View profile:", candidate)}
                      >
                        <User className="w-4 h-4 mr-1" />
                        View Profile
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => console.log("Contact candidate:", candidate)}
                      >
                        <Mail className="w-4 h-4 mr-1" />
                        Contact
                      </Button>
                    </div>
                    
                    <Button
                      variant="default"
                      size="sm"
                      onClick={() => handleExtractSkills(candidate.id)}
                      disabled={extractingSkills === candidate.id}
                    >
                      {extractingSkills === candidate.id ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-1 animate-spin" />
                          Extracting...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4 mr-1" />
                          Extract Skills
                        </>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredCandidates.length === 0 && !loading && (
            <div className="text-center py-12">
              <p className="text-muted-foreground text-lg">No candidates found matching your search.</p>
              <Button className="mt-4" onClick={() => setSearchTerm("")}>
                Clear Search
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Candidates;